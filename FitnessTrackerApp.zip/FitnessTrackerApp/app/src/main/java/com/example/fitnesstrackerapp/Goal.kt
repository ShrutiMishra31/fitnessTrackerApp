package com.example.fitnesstrackerapp

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val target: Int,
    val description: String,
    val targetValue: Int,
    val currentValue: Int = 0,
    val deadline: Date
)
