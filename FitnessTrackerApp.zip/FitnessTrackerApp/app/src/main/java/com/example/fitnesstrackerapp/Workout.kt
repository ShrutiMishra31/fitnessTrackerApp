package com.example.fitnesstrackerapp

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "workouts")
data class Workout(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val duration: Int
) {
    init {
        require(duration > 0) { "Duration must be positive" }
    }
}
