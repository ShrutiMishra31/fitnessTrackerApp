package com.example.fitnesstrackerapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var workoutAdapter: WorkoutAdapter
    private lateinit var workoutList: MutableList<Workout>

    private lateinit var goalAdapter: GoalAdapter
    private lateinit var goalList: MutableList<Goal>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the Room database
        db = AppDatabase.getDatabase(this)
        workoutList = mutableListOf()
        goalList = mutableListOf() // Initialize goal list

        // Set up RecyclerView for workouts
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        workoutAdapter = WorkoutAdapter(workoutList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = workoutAdapter

        // Set up RecyclerView for goals
        val goalsRecyclerView = findViewById<RecyclerView>(R.id.goalsRecyclerView)
        goalAdapter = GoalAdapter(goalList)
        goalsRecyclerView.layoutManager = LinearLayoutManager(this)
        goalsRecyclerView.adapter = goalAdapter

        val workoutTypeInput = findViewById<EditText>(R.id.workoutTypeInput)
        val durationInput = findViewById<EditText>(R.id.durationInput)
        val saveButton = findViewById<Button>(R.id.btnSaveWorkout)

        val goalInput = findViewById<EditText>(R.id.goalInput)
        val saveGoalButton = findViewById<Button>(R.id.btnSaveGoal)

        // Handle Save button click for workouts
        saveButton.setOnClickListener {
            val workoutType = workoutTypeInput.text.toString()
            val duration = durationInput.text.toString().toIntOrNull()

            if (workoutType.isNotEmpty() && duration != null) {
                val workout = Workout(type = workoutType, duration = duration)

                lifecycleScope.launch {
                    try {
                        db.workoutDao().insertWorkout(workout)
                        // Fetch updated list of workouts
                        val workouts = db.workoutDao().getAllWorkouts()

                        // Update RecyclerView on the main thread
                        workoutList.clear()
                        workoutList.addAll(workouts)
                        workoutAdapter.notifyDataSetChanged()

                        Toast.makeText(this@MainActivity, "Workout Saved", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Error saving workout: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Please fill all fields correctly", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle Save button click for goals
        saveGoalButton.setOnClickListener {
            val goalValue = goalInput.text.toString().toIntOrNull()

            if (goalValue != null) {
                val goal = Goal(
                    target = goalValue,
                    description = "Achieve $goalValue workouts",
                    targetValue = goalValue,
                    currentValue = 0,
                    deadline = Date()
                )


                lifecycleScope.launch {
                    try {
                        db.goalDao().insertGoal(goal)
                        // Fetch updated list of goals
                        val goals = db.goalDao().getAllGoals()


                        goalList.clear()
                        goalList.addAll(goals)
                        goalAdapter.notifyDataSetChanged()

                        Toast.makeText(this@MainActivity, "Goal Saved", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Error saving goal: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Please enter a valid goal", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
