package com.example.fitnesstrackerapp

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface GoalDao {
    @Insert
    suspend fun insertGoal(goal: Goal): Long

    @Query("SELECT * FROM goals")
    suspend fun getAllGoals(): List<Goal>

    @Query("UPDATE goals SET currentValue = :value WHERE id = :goalId")
    suspend fun updateGoalProgress(goalId: Long, value: Int)
}
